import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MovieDetails } from './movie';

@Injectable({
    providedIn: 'root'
})
export class SearchService {
    // searchMovie(title: String) {
    //     const url = 'http://www.omdbapi.com/?s=' + title + '&apikey=35346456';
    //     return this.http.get(url)
    //                 .map((response: Response) => {
    //                     return response.json();
    //                 });
    // }
    baseUrl = 'http://localhost:8090/api/v1/movieservice/movies';
    constructor( private http: HttpClient ) {}
    getMovies(title: string) {
        return fetch('http://www.omdbapi.com/?s=' + title + '&apikey=8f89faaf')
                .then(response => response.json());
    }
    getWhishList(): Observable<MovieDetails[]> {
        return this.http.get<MovieDetails[]>(this.baseUrl);
    }

    deleteMovie(id: number) {
        return fetch(this.baseUrl + '/' + {id}).then(response1 => response1.json());
    }

}
