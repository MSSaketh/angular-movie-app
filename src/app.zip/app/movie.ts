export class MovieDetails {
     movieId: number;
     movieName: string;
    //  movieRating: number;
    //  movieDesc: string;
     movieYear: number;
}
